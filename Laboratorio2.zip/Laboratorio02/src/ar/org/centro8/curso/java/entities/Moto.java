package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public class Moto extends Vehiculo{

    private int cilindrada;

    public Moto(int cilindrada, String marca, String modelo, double precio) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return "Marca: "+ super.getMarca() + "  //  Modelo: "+ super.getModelo() 
                + "  //  Cilindrada: " + cilindrada + "c  //  Precio: $" + super.getPrecioFormat();
    }

    public int getCilindrada() {
        return cilindrada;
    }
    
    
}