package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public class Auto extends Vehiculo{

    private int puertas;

    public Auto(int puertas, String marca, String modelo, double precio) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        return "Marca: "+ super.getMarca() + "  //  Modelo: "+ super.getModelo() 
                + "  //  Puertas: " + puertas + "  //  Precio: $" + super.getPrecioFormat();
    }

    public int getPuertas() {
        return puertas;
    }
    
    
    
    
}